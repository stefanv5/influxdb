## 1. []Value 切片复用 (BlockValueIterator)

- [ ] 1.1 修改 `Init()` 中的 `DecodeBlock(buf, nil)` 为 `DecodeBlock(buf, it.decoded[:0])`
- [ ] 1.2 修改 `NextBlock()` 中的 `DecodeBlock(buf, nil)` 为 `DecodeBlock(buf, it.decoded[:0])`
- [ ] 1.3 修改 `ActivatePending()` 中的 `DecodeBlock(it.nextRaw, nil)` 为 `DecodeBlock(it.nextRaw, it.decoded[:0])`

## 2. StringArray 池化 (KeyAwareMergingIterator)

- [ ] 2.1 在 `KeyAwareMergingIterator` 结构体上添加 typed array 字段：`floatArr *tsdb.FloatArray`、`integerArr *tsdb.IntegerArray`、`unsignedArr *tsdb.UnsignedArray`、`booleanArr *tsdb.BooleanArray`、`stringArr *tsdb.StringArray`
- [ ] 2.2 修改 `encodeValues` 的 `BlockFloat64` 分支：复用 `m.floatArr`，初始化时 `m.floatArr = &tsdb.FloatArray{}`，每次 reset `Timestamps/Values` 为 `[:0]`
- [ ] 2.3 修改 `encodeValues` 的 `BlockInteger` 分支：复用 `m.integerArr`
- [ ] 2.4 修改 `encodeValues` 的 `BlockUnsigned` 分支：复用 `m.unsignedArr`
- [ ] 2.5 修改 `encodeValues` 的 `BlockBoolean` 分支：复用 `m.booleanArr`
- [ ] 2.6 修改 `encodeValues` 的 `BlockString` 分支：复用 `m.stringArr`

## 3. 生命周期管理 — nil 化 buffer 元素

- [ ] 3.1 在 `Read()` 中 `encodeValues` 成功返回后，遍历 `m.buf` 将每个元素设为 `Value{}`，然后再 `m.buf = m.buf[:0]`

## 4. Key buffer 复用

- [ ] 4.1 在 `KeyAwareMergingIterator` 上添加 `keyBuf []byte` 字段，`Read()` 中复用该 buffer 拷贝 key
- [ ] 4.2 在 `streamingKeyIterator` 上添加 `keyBuf []byte` 字段，`Read()` 中复用该 buffer 拷贝 key

## 5. 验证

- [ ] 5.1 运行 `go test -race ./tsdb/engine/tsm1/...` 确保无 race condition
- [ ] 5.2 运行 `go test -run TestStreamingKeyIterator ./tsdb/engine/tsm1/...` 确保 streaming compact 功能正确
- [ ] 5.3 运行 `go test -run TestCompact ./tsdb/engine/tsm1/...` 确保 compact 流程无回归
